Pred pouzivanim doplnku VyhledavaniRUIAN je nutne nejprve spravne nastavit cesty k datum RUIAN v konfiguracnim souboru, vice informaci v dokumentaci VyhledavaniRUIANAddin.pdf.
 